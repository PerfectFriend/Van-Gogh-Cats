#!/usr/bin/env bash
set -e
echo "Установка Van Gogh CryptoCats для текущего пользователя..."
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p ~/.local/bin ~/.local/share/applications ~/.local/share/icons/hicolor/512x512/apps

cp "${DIR}/launch.sh" ~/.local/bin/vangogh-cats-gallery
chmod +x ~/.local/bin/vangogh-cats-gallery

cp "${DIR}/vangogh-cats-gallery.png" ~/.local/share/icons/hicolor/512x512/apps/
cp "${DIR}/vangogh-cats-gallery.desktop" ~/.local/share/applications/
sed -i "s|/usr/bin/vangogh-cats-gallery|${HOME}/.local/bin/vangogh-cats-gallery|g" ~/.local/share/applications/vangogh-cats-gallery.desktop

if which update-desktop-database >/dev/null 2>&1; then
  update-desktop-database ~/.local/share/applications 2>/dev/null || true
fi
if which gtk-update-icon-cache >/dev/null 2>&1; then
  gtk-update-icon-cache -f -t ~/.local/share/icons/hicolor 2>/dev/null || true
fi

echo "Готово! Приложение установлено в ~/.local/bin/vangogh-cats-gallery"
