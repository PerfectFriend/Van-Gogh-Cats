#!/usr/bin/env bash
# Van Gogh CryptoCats - Native Ubuntu/Linux Launcher
set -e

APP_NAME="Van Gogh CryptoCats"
DEFAULT_URL="https://ais-pre-ypwd3d2freqhamtros5prz-468670053177.europe-west3.run.app"
TARGET_URL="${VANGOGH_URL:-$DEFAULT_URL}"
DATA_DIR="${HOME}/.local/share/vangogh-cats-gallery"
PROFILE_DIR="${DATA_DIR}/profile"

mkdir -p "${DATA_DIR}" "${PROFILE_DIR}"

for arg in "$@"; do
  case $arg in
    --url=*)
      TARGET_URL="${arg#*=}"
      shift
      ;;
    --help|-h)
      echo "$APP_NAME - Art Gallery & AI Post-Impressionist Studio"
      echo ""
      echo "Использование: vangogh-cats-gallery [опции]"
      echo ""
      echo "Опции:"
      echo "  --url=<URL>     Открыть кастомный URL деплоя или локального сервера"
      echo "  --help, -h      Показать данную справку"
      echo "  --version, -v   Показать версию приложения"
      echo ""
      echo "Окружение:"
      echo "  VANGOGH_URL     Переопределение целевого адреса сервиса"
      exit 0
      ;;
    --version|-v)
      echo "$APP_NAME version 1.0.0 (Ubuntu Release Candidate)"
      exit 0
      ;;
  esac
done

# Try modern browsers in order of native application mode (--app) support
if command -v google-chrome &> /dev/null; then
  exec google-chrome --app="${TARGET_URL}" --class="${APP_NAME}" --user-data-dir="${PROFILE_DIR}" "$@"
elif command -v chromium-browser &> /dev/null; then
  exec chromium-browser --app="${TARGET_URL}" --class="${APP_NAME}" --user-data-dir="${PROFILE_DIR}" "$@"
elif command -v chromium &> /dev/null; then
  exec chromium --app="${TARGET_URL}" --class="${APP_NAME}" --user-data-dir="${PROFILE_DIR}" "$@"
elif command -v brave-browser &> /dev/null; then
  exec brave-browser --app="${TARGET_URL}" --class="${APP_NAME}" --user-data-dir="${PROFILE_DIR}" "$@"
elif command -v microsoft-edge &> /dev/null; then
  exec microsoft-edge --app="${TARGET_URL}" --class="${APP_NAME}" --user-data-dir="${PROFILE_DIR}" "$@"
elif command -v firefox &> /dev/null; then
  exec firefox --new-window "${TARGET_URL}" "$@"
elif command -v xdg-open &> /dev/null; then
  exec xdg-open "${TARGET_URL}" "$@"
else
  echo "Ошибка: Не найден подходящий браузер (Chrome, Chromium, Brave или Firefox)." >&2
  exit 1
fi
